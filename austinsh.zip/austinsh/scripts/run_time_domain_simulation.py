import numpy as np
# Initializing Y and J matrix in here and initialize stamps

def run_time_domain_simulation(devices, V_init, SETTINGS, Y_size):
    # Newton Rapshon Method Initialization
    # n = 0
    # while abs() and n < SETTINGS["Max Iters"]:
    #     n += 1
    V_waveform = None
    # Initialize a matrix full of zeroes for matrix Y
    Y_matrix = np.zeros((Y_size, Y_size))
    return V_waveform