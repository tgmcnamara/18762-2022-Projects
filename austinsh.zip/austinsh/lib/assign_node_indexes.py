
def assign_node_indexes(devices):
    node_index_counter = 0
    #TODO
    # For i in resistors
        # Nodes.assign
    return node_index_counter