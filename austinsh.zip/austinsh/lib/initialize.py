

def initialize(devices, size_Y):
    V_init = None
    return V_init