

def stamp_sparse():
    pass

def stamp_dense():
    pass